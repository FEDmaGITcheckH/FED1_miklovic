var data = "Maxo Miklovič";

console.log(data);

data += " býva v Bratislave!";

console.log(data);
